namespace Brezenhem {
	enum State { IDLE, LINE, CIRCLE, ELLIPSE };
}